# Guía de Configuración - Apache Tomcat 11
**Migración de Rutas Absolutas**

---

## 📋 Índice

1. [Archivos a Modificar](#archivos-a-modificar)
2. [Guía de Cambios](#guía-de-cambios)

---

## Archivos a Modificar

### 🔴 Requieren cambios obligatorios:
- ✏️ `conf/server.xml`
- ✏️ `conf/context.xml`

### ✅ No requieren cambios:
- `conf/catalina.properties`
- `conf/logging.properties`
- `conf/web.xml`
- `conf/tomcat-users.xml`

---

## Guía de Cambios

### 1. `conf/server.xml`

**Buscar:** Elemento `<Context>` dentro de `<Host>`

**Modificar:** Atributo `docBase`

```xml
<Context docBase="[RUTA_ABSOLUTA_APLICACION_WEB]" 
         path="/turismouy.UI" 
         reloadable="true"/>
```

**Ejemplo:**
```xml
<!-- Linux -->
docBase="/opt/tomcat/webapps/turismouy.UI"

<!-- Windows -->
docBase="C:\Apache\Tomcat\webapps\turismouy.UI"
```

---

### 2. `conf/context.xml`

**Buscar:** Elementos `<PreResources>` dentro de `<Resources>`

**Opción A - Rutas relativas** (recomendado):
```xml
<PreResources base="${catalina.base}/data/turismouy.UI/profile_img" .../>
<PreResources base="${catalina.base}/data/turismouy.UI/res" .../>
```
➜ Crear estructura: `[CATALINA_BASE]/data/turismouy.UI/{profile_img,res}`

**Opción B - Rutas absolutas:**
```xml
<!-- Linux -->
<PreResources base="/ruta/datos/profile_img" .../>
<PreResources base="/ruta/datos/res" .../>

<!-- Windows -->
<PreResources base="C:\datos\profile_img" .../>
<PreResources base="C:\datos\res" .../>
```

---

**Versión:** Tomcat 11.0.11  
**Aplicación:** turismouy.UI
